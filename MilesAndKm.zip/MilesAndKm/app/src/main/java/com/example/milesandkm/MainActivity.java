package com.example.milesandkm;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;

import androidx.appcompat.app.AppCompatActivity;

import java.text.DecimalFormat;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        Button buttonMilesToKm = findViewById(R.id.buttonMilesToKm);
        buttonMilesToKm.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                EditText Miles = findViewById(R.id.etMiles);
                EditText Km = findViewById(R.id.etKm);
                double vMiles;
                vMiles = Double.parseDouble(Miles.getText().toString());
                double vKm = vMiles/0.62317;
                DecimalFormat formatVal = new DecimalFormat("##.##");
                Km.setText(formatVal.format(vKm));
            }
        });
        Button buttonKmToMiles = findViewById(R.id.buttonKmToMiles);
        buttonKmToMiles.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                EditText Miles = findViewById(R.id.etMiles);
                EditText Km = findViewById(R.id.etKm);
                double vKm = Double.parseDouble(Km.getText().toString());
                double vMiles = vKm*0.62317;
                DecimalFormat formatVal = new DecimalFormat("##.##");
                Miles.setText(formatVal.format(vMiles));
            }
        });
    }
}
